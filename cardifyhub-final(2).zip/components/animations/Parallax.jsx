'use client';export default function Parallax({children}){return <div>{children}</div>}
