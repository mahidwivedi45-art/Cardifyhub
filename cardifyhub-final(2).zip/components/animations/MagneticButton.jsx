'use client';export default function MagneticButton({children}){return <div>{children}</div>}
