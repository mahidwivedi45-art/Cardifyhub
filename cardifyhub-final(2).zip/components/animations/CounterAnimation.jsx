'use client';export default function CounterAnimation({children}){return <div>{children}</div>}
