'use client';export default function ScrollScene({children}){return <div>{children}</div>}
