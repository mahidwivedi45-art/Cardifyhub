'use client';export default function StoreScene(){return <div className="pointer-events-none absolute inset-0" aria-hidden="true"/>}
