'use client';export default function Dashboard3D(){return <div className="pointer-events-none absolute inset-0" aria-hidden="true"/>}
