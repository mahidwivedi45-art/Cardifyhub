import {NextResponse} from 'next/server';export async function GET(){return NextResponse.json({revenue:0,costs:0,profit:0,margin:0},{status:501});}
