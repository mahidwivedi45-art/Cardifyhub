import {NextResponse} from 'next/server';export async function POST(){return NextResponse.json({ok:false,message:'Shopify webhook requires authenticated production integration.'},{status:501});}
