import {NextResponse} from 'next/server';export async function POST(){return NextResponse.json({ok:false,message:'Shopify sync requires authenticated production integration.'},{status:501});}
