import {NextResponse} from 'next/server';export async function POST(){return NextResponse.json({ok:false,message:'WooCommerce webhook requires authenticated production integration.'},{status:501});}
